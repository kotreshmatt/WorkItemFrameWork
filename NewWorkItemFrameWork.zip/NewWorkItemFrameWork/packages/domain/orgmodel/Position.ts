export interface Position {
    id: string;
    name: string;
    orgUnitId: string;
  }
  