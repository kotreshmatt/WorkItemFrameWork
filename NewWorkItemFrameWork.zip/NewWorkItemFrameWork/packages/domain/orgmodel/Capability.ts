export interface Capability {
    id: string;
    name: string;
  }
  