export interface Privilege {
    id: string;
    name: string;
  }
  