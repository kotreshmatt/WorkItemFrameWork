export interface OrgUnit {
    id: string;
    name: string;
    parentId?: string;
  }
  