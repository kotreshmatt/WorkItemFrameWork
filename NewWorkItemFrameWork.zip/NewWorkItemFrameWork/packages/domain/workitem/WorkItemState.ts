export enum WorkItemState {
    NEW = 'NEW',
    ACTIVE = 'ACTIVE',
    CLAIMED = 'CLAIMED',
    COMPLETED = 'COMPLETED',
    CANCELLED = 'CANCELLED'
  }
  