export enum WorkItemType {
    HUMAN_TASK = 'HUMAN_TASK',
    SYSTEM_TASK = 'SYSTEM_TASK'
  }
  