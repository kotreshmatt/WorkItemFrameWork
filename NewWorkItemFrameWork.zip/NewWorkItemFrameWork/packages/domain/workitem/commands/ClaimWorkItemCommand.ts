import { WorkItemCommand } from './WorkItemCommand';

export interface ClaimWorkItemCommand extends WorkItemCommand {}
